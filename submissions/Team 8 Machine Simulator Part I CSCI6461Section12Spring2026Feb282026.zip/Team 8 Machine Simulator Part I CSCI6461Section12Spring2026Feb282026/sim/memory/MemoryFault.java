package cisc.sim.memory;

public class MemoryFault extends Exception {
    public MemoryFault(String msg) { super(msg); }
}